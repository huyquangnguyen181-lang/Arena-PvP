# Về spawn xanh
tp @s 1057 66 1057
