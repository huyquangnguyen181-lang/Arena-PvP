# Xóa toàn bộ arena
fill 1000 63 1000 1060 71 1060 air
fill 990 64 990 999 64 999 air
fill 1061 64 1061 1070 64 1070 air
say === Arena đã bị xóa. Chạy lại /function pvp:build để dựng mới ===
