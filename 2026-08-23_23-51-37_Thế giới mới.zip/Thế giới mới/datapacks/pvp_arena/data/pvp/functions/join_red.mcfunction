# Về spawn đỏ
tp @s 1003 66 1003
