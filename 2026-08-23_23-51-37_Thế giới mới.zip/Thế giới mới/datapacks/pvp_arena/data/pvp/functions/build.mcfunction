# ==== MACE PVP ARENA — build by Codebuff ====
# Arena 61x61, tâm (1030, 1030), sàn y=64

# ---- Nền & sàn ----
fill 1000 63 1000 1060 63 1060 stone_bricks
fill 1000 64 1000 1060 64 1060 polished_deepslate

# ---- Viền vàng 4 cạnh ----
fill 1000 64 1000 1060 64 1000 gold_block
fill 1000 64 1060 1060 64 1060 gold_block
fill 1000 64 1000 1000 64 1060 gold_block
fill 1060 64 1000 1060 64 1060 gold_block

# ---- Tường bao quanh (đá thấp + kính cao nhìn xuyên) ----
fill 1000 65 1000 1060 66 1000 stone_bricks
fill 1000 65 1060 1060 66 1060 stone_bricks
fill 1000 65 1000 1000 66 1060 stone_bricks
fill 1060 65 1000 1060 66 1060 stone_bricks
fill 1000 67 1000 1060 68 1000 glass
fill 1000 67 1060 1060 68 1060 glass
fill 1000 67 1000 1000 68 1060 glass
fill 1060 67 1000 1060 68 1060 glass

# ---- Đèn sea lantern trên tường ----
setblock 1000 66 1000 sea_lantern
setblock 1060 66 1000 sea_lantern
setblock 1000 66 1060 sea_lantern
setblock 1060 66 1060 sea_lantern
setblock 1030 66 1000 sea_lantern
setblock 1030 66 1060 sea_lantern
setblock 1000 66 1030 sea_lantern
setblock 1060 66 1030 sea_lantern

# ---- Cột trung tâm (nhảy lên smash xuống) ----
fill 1030 64 1030 1030 70 1030 obsidian
setblock 1030 71 1030 sea_lantern

# ---- 4 cột phụ cao 3 khối ----
fill 1015 64 1015 1015 67 1015 polished_blackstone_bricks
setblock 1015 68 1015 sea_lantern
fill 1045 64 1015 1045 67 1015 polished_blackstone_bricks
setblock 1045 68 1015 sea_lantern
fill 1015 64 1045 1015 67 1045 polished_blackstone_bricks
setblock 1015 68 1045 sea_lantern
fill 1045 64 1045 1045 67 1045 polished_blackstone_bricks
setblock 1045 68 1045 sea_lantern

# ---- Bậc trung gian (tầng 2 cho mace) ----
fill 1005 65 1005 1010 65 1010 red_terracotta
fill 1050 65 1050 1055 65 1055 blue_terracotta

# ---- Spawn platforms đỏ / xanh ----
fill 1002 65 1002 1004 65 1004 red_wool
fill 1056 65 1056 1058 65 1058 blue_wool

# ---- Khu vực an toàn bên ngoài (điểm đứng xem) ----
fill 990 64 990 999 64 999 polished_deepslate
fill 1061 64 1061 1070 64 1070 polished_deepslate

say === Arena PvP đã dựng xong! ===
say Chạy /function pvp:setup rồi /function pvp:join_red hoặc /function pvp:join_blue
