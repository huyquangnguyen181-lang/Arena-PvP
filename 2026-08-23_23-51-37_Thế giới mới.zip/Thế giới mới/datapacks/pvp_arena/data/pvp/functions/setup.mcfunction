# Gamerules PvP chuẩn
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule keepInventory true
gamerule mobGriefing false
gamerule pvp true
gamerule naturalRegeneration true
time set day
weather clear
say === Đã áp dụng gamerules PvP (giữ đồ khi chết, không đổi ngày/đêm, không phá hủy khối) ===
