# Hướng dẫn sử dụng
tellraw @s ["",{"text":"===== MACE PVP ARENA =====\n","color":"gold","bold":true}]
tellraw @s ["",{"text":"/function pvp:build","color":"aqua"},{"text":"  — dựng arena\n","color":"gray"}]
tellraw @s ["",{"text":"/function pvp:setup","color":"aqua"},{"text":"  — áp dụng gamerules PvP\n","color":"gray"}]
tellraw @s ["",{"text":"/function pvp:join_red","color":"aqua"},{"text":" / ","color":"gray"},{"text":"pvp:join_blue","color":"aqua"},{"text":"  — về spawn đỏ/xanh\n","color":"gray"}]
tellraw @s ["",{"text":"/function pvp:kit","color":"aqua"},{"text":"  — nhận kit mace\n","color":"gray"}]
tellraw @s ["",{"text":"/function pvp:reset","color":"aqua"},{"text":"  — xóa arena\n","color":"gray"}]
tellraw @s ["",{"text":"Mẹo: nhảy lên cột trung tâm (obsidian giữa sân) rồi smash mace xuống đối thủ!","color":"yellow"}]
