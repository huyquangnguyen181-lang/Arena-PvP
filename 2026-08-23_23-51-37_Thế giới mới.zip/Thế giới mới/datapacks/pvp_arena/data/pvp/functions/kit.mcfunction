# Kit Mace PvP
clear @s
give @s minecraft:mace 1
give @s minecraft:iron_sword 1
give @s minecraft:shield 1
give @s minecraft:bow 1
give @s minecraft:arrow 16
give @s minecraft:cooked_beef 16
give @s minecraft:golden_apple 2
give @s minecraft:iron_helmet 1
give @s minecraft:iron_chestplate 1
give @s minecraft:iron_leggings 1
give @s minecraft:iron_boots 1
say === Bạn đã nhận kit Mace PvP (mace, kiếm, khiên, cung, đồ ăn) ===
