# Boss and Airdrop schedule

After `/reload`, the timer begins again from zero.

* Boss wave: every 12,000 ticks (10 real-time minutes at 20 TPS). It removes every old `pvp_boss`, then creates exactly three new bosses in the PvP arena bounds.
* Airdrop: every 18,000 ticks (15 real-time minutes at 20 TPS). It removes the old airdrop, then creates one random white shulker box and its guardian.
* The shulker box is locked until its guardian dies. It contains 1–3 random stacks based on existing boss reward items. Once all items are taken, the box removes itself.

## Test commands

`/function pvp:boss/spawn` — run a boss wave now.

`/function pvp:airdrop/spawn` — create an airdrop now.

`/function pvp:airdrop/cleanup` — remove the active airdrop and guardian.

Minecraft datapacks cannot read the Windows/server wall clock, so an exact 20:00 / 20:10 / 20:15 real-world schedule is not possible from a datapack alone. The implemented schedule is a 10- and 15-minute cycle starting at `/reload` or world start. Clock-aligned spawning would require a server scheduler or plugin.
