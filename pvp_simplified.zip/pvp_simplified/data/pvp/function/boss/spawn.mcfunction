scoreboard players set #boss_timer pvp_timer 0
function pvp:boss/clear_silent
function pvp:boss/spawn_slot_1
function pvp:boss/spawn_slot_2
function pvp:boss/spawn_slot_3
tellraw @a [{"text":"[ARENA BOSS] ","color":"gold","bold":true},{"text":"3 boss đã xuất hiện ngẫu nhiên trong PvP arena. Đợt boss cũ đã được thay thế!","color":"red"}]
function pvp:boss/update_bars
