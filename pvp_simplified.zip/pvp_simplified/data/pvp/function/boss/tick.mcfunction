execute if entity @e[type=minecraft:wither_skeleton,tag=pvp_boss,limit=1] run function pvp:boss/update_bars
function pvp:boss/timer
