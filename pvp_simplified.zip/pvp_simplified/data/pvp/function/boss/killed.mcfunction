advancement revoke @s only pvp:kill_boss
scoreboard players add @s kills 1
bossbar set pvp:boss_hp_1 visible false
bossbar set pvp:boss_hp_2 visible false
bossbar set pvp:boss_hp_3 visible false
tellraw @a [{"text":"[ARENA BOSS] ","color":"gold","bold":true},{"selector":"@s","color":"yellow"},{"text":" killed the PvP Boss and received random PvP items!","color":"gold"}]
title @s times 5 30 5
title @s title {"text":"+1 BOSS KILL","color":"gold","bold":true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
function pvp:update_rank
function pvp:reward/random_bundle
