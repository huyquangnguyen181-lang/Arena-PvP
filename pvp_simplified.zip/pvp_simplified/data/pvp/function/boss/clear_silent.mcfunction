kill @e[type=minecraft:wither_skeleton,tag=pvp_boss]
bossbar set pvp:boss_hp_1 visible false
bossbar set pvp:boss_hp_2 visible false
bossbar set pvp:boss_hp_3 visible false
