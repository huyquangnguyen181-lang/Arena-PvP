bossbar set pvp:boss_hp_1 visible false
bossbar set pvp:boss_hp_2 visible false
bossbar set pvp:boss_hp_3 visible false
scoreboard players add #boss_timer pvp_timer 1
execute if score #boss_timer pvp_timer >= #boss_interval pvp_timer run function pvp:boss/spawn
