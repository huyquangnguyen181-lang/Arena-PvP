bossbar set pvp:boss_hp_1 players @a
bossbar set pvp:boss_hp_2 players @a
bossbar set pvp:boss_hp_3 players @a
bossbar set pvp:boss_hp_1 visible false
bossbar set pvp:boss_hp_2 visible false
bossbar set pvp:boss_hp_3 visible false
scoreboard players set #bar1 pvp_tmp 0
scoreboard players set #bar2 pvp_tmp 0
scoreboard players set #bar3 pvp_tmp 0
execute if entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_1,limit=1] run bossbar set pvp:boss_hp_1 visible true
execute if entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_2,limit=1] run bossbar set pvp:boss_hp_2 visible true
execute if entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_3,limit=1] run bossbar set pvp:boss_hp_3 visible true
execute store result score #bar1 pvp_tmp run data get entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_1,limit=1] Health 1
execute store result score #bar2 pvp_tmp run data get entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_2,limit=1] Health 1
execute store result score #bar3 pvp_tmp run data get entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_3,limit=1] Health 1
execute store result bossbar pvp:boss_hp_1 value run scoreboard players get #bar1 pvp_tmp
execute store result bossbar pvp:boss_hp_2 value run scoreboard players get #bar2 pvp_tmp
execute store result bossbar pvp:boss_hp_3 value run scoreboard players get #bar3 pvp_tmp
