kill @e[type=minecraft:wither_skeleton,tag=pvp_boss]
bossbar set pvp:boss_hp_1 visible false
bossbar set pvp:boss_hp_2 visible false
bossbar set pvp:boss_hp_3 visible false
scoreboard players set #boss_timer pvp_timer 0
tellraw @a [{"text":"[ARENA BOSS] ","color":"gold","bold":true},{"text":"Cleared current PvP Boss mobs.","color":"green"}]
