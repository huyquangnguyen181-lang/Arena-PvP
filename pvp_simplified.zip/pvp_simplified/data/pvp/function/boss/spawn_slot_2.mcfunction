summon minecraft:marker 0 0 0 {Tags:["pvp_boss_spawn_marker","pvp_boss_spawn_2"]}
execute store result score #boss_x pvp_tmp run random value 25..113
execute store result score #boss_y pvp_tmp run random value -31..9
execute store result score #boss_z pvp_tmp run random value -8..85
execute store result entity @e[type=minecraft:marker,tag=pvp_boss_spawn_2,limit=1] Pos[0] double 1 run scoreboard players get #boss_x pvp_tmp
execute store result entity @e[type=minecraft:marker,tag=pvp_boss_spawn_2,limit=1] Pos[1] double 1 run scoreboard players get #boss_y pvp_tmp
execute store result entity @e[type=minecraft:marker,tag=pvp_boss_spawn_2,limit=1] Pos[2] double 1 run scoreboard players get #boss_z pvp_tmp
execute store result score #boss_type pvp_random run random value 1..2
execute as @e[type=minecraft:marker,tag=pvp_boss_spawn_2,limit=1] at @s if score #boss_type pvp_random matches 1 run function pvp:boss/summon_weak_2
execute as @e[type=minecraft:marker,tag=pvp_boss_spawn_2,limit=1] at @s if score #boss_type pvp_random matches 2 run function pvp:boss/summon_strong_2
data modify entity @e[type=minecraft:wither_skeleton,tag=pvp_boss_2,limit=1] CustomName set value '{"text":"BOSS ARENA #2","color":"gold","bold":true}'
kill @e[type=minecraft:marker,tag=pvp_boss_spawn_2,limit=1]
