scoreboard players operation @s pvp_tmp = @s pvp_zombie_kills
scoreboard players operation @s pvp_tmp -= @s pvp_zombie_seen
scoreboard players operation @s kills += @s pvp_tmp
scoreboard players operation @s pvp_zombie_seen = @s pvp_zombie_kills
tellraw @a ["",{"text":"[ARENA] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" killed a zombie test mob! Kills: ","color":"white"},{"score":{"name":"@s","objective":"kills"},"color":"yellow","bold":true}]
title @s times 5 20 5
title @s title {"text":"+1 KILL","color":"green","bold":true}
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
function pvp:update_rank
