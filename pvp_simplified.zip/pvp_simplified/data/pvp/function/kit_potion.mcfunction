# Kit Potion - Mine Berry Coins Shoop

#Armor Legendary

item replace entity @s armor.head with netherite_helmet[enchantments={protection:4,respiration:3,unbreaking:3,mending:1}]
item replace entity @s armor.chest with netherite_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]
item replace entity @s armor.legs with netherite_leggings[enchantments={protection:4,soul_speed:3,unbreaking:3,mending:1}]
item replace entity @s armor.feet with netherite_boots[enchantments={protection:4,feather_falling:4,depth_strider:3,unbreaking:3,mending:1}]
item replace entity @s weapon.offhand with totem_of_undying


give @s minecraft:mace[enchantments={unbreaking:1,mending:1,smite:10,bane_of_arthropods:2,fire_aspect:2,looting:5,breach:4,wind_burst:1,vanishing_curse:10}]
give @s minecraft:elytra[enchantments={unbreaking:10,vanishing_curse:10}]
give @s minecraft:netherite_axe[enchantments={sharpness:5,vanishing_curse:10,efficiency:1,unbreaking:1,mending:1}]
give @s minecraft:netherite_sword[enchantments={sharpness:5,unbreaking:3,knockback:1,fire_aspect:2,looting:10,unbreaking:3,mending:1,vanishing_curse:10}]
give @s minecraft:golden_apple[enchantments={breach:4,vanishing_curse:10}] 128
give @s minecraft:mace[enchantments={unbreaking:1,mending:1,smite:10,bane_of_arthropods:2,fire_aspect:2,looting:5,density:5,wind_burst:1,vanishing_curse:10}]
give @s minecraft:wind_charge[enchantments={breach:4,vanishing_curse:10}] 64
give @s minecraft:ender_pearl[enchantments={breach:4,vanishing_curse:10}] 16
give @s minecraft:bow[enchantments={punch:2,unbreaking:10,power:100,flame:10,quick_charge:244,vanishing_curse:10}]
give @s minecraft:totem_of_undying[enchantments={breach:4,vanishing_curse:10}] 2
give @s minecraft:wind_charge[enchantments={breach:4,vanishing_curse:10}] 64
give @s minecraft:ender_pearl[enchantments={breach:4,vanishing_curse:10}] 16
give @s minecraft:crossbow[enchantments={punch:2,unbreaking:10,power:1,flame:10,quick_charge:3,vanishing_curse:10,multishot:1}]
give @s minecraft:totem_of_undying[enchantments={breach:4,vanishing_curse:10}] 2
give @s minecraft:totem_of_undying[enchantments={breach:4,vanishing_curse:10}] 2
give @s minecraft:wind_charge[enchantments={breach:4,vanishing_curse:10}] 64
give @s minecraft:ender_pearl[enchantments={breach:4,vanishing_curse:10}] 16
give @s minecraft:arrow[enchantments={breach:4,vanishing_curse:10}] 64
give @s minecraft:totem_of_undying[enchantments={breach:4,vanishing_curse:10}] 2
give @s minecraft:wind_charge[enchantments={breach:4,vanishing_curse:10}] 64
give @s minecraft:ender_pearl[enchantments={breach:4,vanishing_curse:10}] 16
give @s minecraft:shield[enchantments={unbreaking:10,vanishing_curse:10}]
give @s minecraft:firework_rocket[enchantments={mending:1,unbreaking:3,vanishing_curse:10}] 256
give @s minecraft:netherite_axe[enchantments={unbreaking:10,efficiency:10}]

# Potions MAX

give @s minecraft:totem_of_undying[custom_name={text:"Totem – Strong Health II",color:"yellow",bold:true,italic:false},enchantments={unbreaking:1},attribute_modifiers=[{id:"minecraft:strong_health",type:"minecraft:max_health",amount:20,operation:"add_value",slot:"offhand"}]] 64
give @s minecraft:totem_of_undying[custom_name={text:'Hulk Totem',color:'aqua',italic:false},enchantment_glint_override=true,attribute_modifiers=[{id:'minecraft:hulk_attack',type:'minecraft:attack_damage',amount:0.3,operation:'add_multiplied_base',slot:'offhand'},{id:'minecraft:hulk_speed',type:'minecraft:movement_speed',amount:-0.3,operation:'add_multiplied_base',slot:'offhand'}]] 64
give @s minecraft:potion[custom_name={text:"Godly Potion",color:"#55FF55",bold:true,italic:false},potion_contents={custom_color:16777215,custom_effects:[{id:"minecraft:slowness",amplifier:5,duration:400},{id:"minecraft:haste",amplifier:1,duration:3600},{id:"minecraft:instant_damage",amplifier:2,duration:1},{id:"minecraft:resistance",amplifier:0,duration:400},{id:"minecraft:regeneration",amplifier:2,duration:3600},{id:"minecraft:resistance",amplifier:1,duration:3800},{id:"minecraft:fire_resistance",amplifier:0,duration:3600},{id:"minecraft:water_breathing",amplifier:0,duration:3600},{id:"minecraft:blindness",amplifier:0,duration:400},{id:"minecraft:night_vision",amplifier:0,duration:3600},{id:"minecraft:health_boost",amplifier:1,duration:3600},{id:"minecraft:glowing",amplifier:0,duration:400},{id:"minecraft:luck",amplifier:1,duration:3600}]}] 64
give @s minecraft:potion[custom_name={text:"Orks Power Potion",color:"#60F560",bold:true,italic:false},potion_contents={custom_color:6350176,custom_effects:[{id:"minecraft:slowness",amplifier:0,duration:4000},{id:"minecraft:strength",amplifier:3,duration:4000}]}] 64
give @s minecraft:potion[potion_contents={custom_color:6155509,custom_effects:[{id:"minecraft:speed",duration:4000,amplifier:3},{id:"minecraft:weakness",duration:4000,amplifier:1}]},custom_name={text:"Assassin's Speed",color:"aqua",bold:true},lore=[{text:"+80% Tốc độ",color:"blue",italic:false},{text:"-8 Sức tấn công",color:"red",italic:false}]] 64
give @s minecraft:potion[potion_contents={custom_color:13945162,custom_effects:[{id:"minecraft:speed",duration:3000,amplifier:2},{id:"minecraft:strength",duration:3000,amplifier:2},{id:"minecraft:regeneration",duration:400,amplifier:1},{id:"minecraft:resistance",duration:400,amplifier:0},{id:"minecraft:fire_resistance",duration:6000,amplifier:0}]},custom_name={text:"Elfin ale Potion",color:"yellow",bold:true},lore=[{text:"Khai thác đặc biệt!",color:"dark_purple",italic:false}]] 64
give @s minecraft:potion[custom_name={text:"Chitin Skin",color:"#5454FC",bold:true,italic:false},potion_contents={custom_color:5526780,custom_effects:[{id:"minecraft:resistance",amplifier:2,duration:6000}]}] 64
give @s minecraft:popped_chorus_fruit[custom_name={text:"Godly Rune",color:"#FFFF55",bold:true,italic:false},enchantments={"minecraft:unbreaking":1},attribute_modifiers=[{id:"minecraft:godly_health",type:"minecraft:max_health",amount:4,operation:"add_value",slot:"offhand"},{id:"minecraft:godly_attack_speed",type:"minecraft:attack_speed",amount:1.2,operation:"add_multiplied_base",slot:"offhand"}]] 64
give @s minecraft:popped_chorus_fruit[custom_name={text:"Rume of Gain",color:"yellow"},enchantment_glint_override=true,attribute_modifiers=[{id:"custom:rume_health",type:"max_health",amount:20,operation:"add_value",slot:"offhand"},{id:"custom:rume_damage",type:"attack_damage",amount:0.2,operation:"add_multiplied_base",slot:"offhand"}]] 64
