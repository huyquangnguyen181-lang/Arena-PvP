kill @e[type=minecraft:wither_skeleton,tag=pvp_airdrop_guard]
execute as @e[type=minecraft:marker,tag=pvp_airdrop_marker] at @s run setblock ~ ~ ~ minecraft:air
kill @e[type=minecraft:marker,tag=pvp_airdrop_marker]
