tag @s add pvp_airdrop_unlocked
execute at @s run data remove block ~ ~ ~ Lock
tellraw @a [{"text":"[AIRDROP] ","color":"aqua","bold":true},{"text":"The guardian has been defeated. The shulker crate is now unlocked!","color":"green"}]
playsound minecraft:block.iron_door.open master @a ~ ~ ~ 1 1
