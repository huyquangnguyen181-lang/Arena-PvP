scoreboard players set #airdrop_timer pvp_timer 0
function pvp:airdrop/cleanup
summon minecraft:marker 0 0 0 {Tags:["pvp_airdrop_marker"]}
execute store result score #airdrop_x pvp_tmp run random value 25..113
execute store result score #airdrop_y pvp_tmp run random value -31..9
execute store result score #airdrop_z pvp_tmp run random value -8..85
execute store result entity @e[type=minecraft:marker,tag=pvp_airdrop_marker,limit=1] Pos[0] double 1 run scoreboard players get #airdrop_x pvp_tmp
execute store result entity @e[type=minecraft:marker,tag=pvp_airdrop_marker,limit=1] Pos[1] double 1 run scoreboard players get #airdrop_y pvp_tmp
execute store result entity @e[type=minecraft:marker,tag=pvp_airdrop_marker,limit=1] Pos[2] double 1 run scoreboard players get #airdrop_z pvp_tmp
execute as @e[type=minecraft:marker,tag=pvp_airdrop_marker,limit=1] at @s run setblock ~ ~ ~ minecraft:white_shulker_box{Lock:"airdrop_guardian"}
execute as @e[type=minecraft:marker,tag=pvp_airdrop_marker,limit=1] at @s run function pvp:airdrop/fill
execute as @e[type=minecraft:marker,tag=pvp_airdrop_marker,limit=1] at @s run summon minecraft:wither_skeleton ~ ~1 ~ {Tags:["pvp_airdrop_guard"],CustomName:'{"text":"BOSS BẢO VỆ AIRDROP","color":"aqua","bold":true}',CustomNameVisible:1b,PersistenceRequired:1b,Health:250f,attributes:[{id:"minecraft:max_health",base:250},{id:"minecraft:movement_speed",base:0.27},{id:"minecraft:attack_damage",base:12},{id:"minecraft:follow_range",base:64},{id:"minecraft:knockback_resistance",base:0.7}],equipment:{mainhand:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":3}}},head:{id:"minecraft:netherite_helmet",count:1,components:{"minecraft:enchantments":{"minecraft:protection":3}}},chest:{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":3}}}}}
tellraw @a [{"text":"[AIRDROP] ","color":"aqua","bold":true},{"text":"A locked shulker crate and its guardian have appeared somewhere in the PvP arena!","color":"white"}]
