execute store result score #airdrop_count pvp_random run random value 1..3
function pvp:airdrop/roll_slot_0
execute if score #airdrop_count pvp_random matches 2.. run function pvp:airdrop/roll_slot_1
execute if score #airdrop_count pvp_random matches 3 run function pvp:airdrop/roll_slot_2
