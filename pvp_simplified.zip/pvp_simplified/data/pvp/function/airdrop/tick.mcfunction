# 15 minutes = 18,000 game ticks. Only one active crate/guardian is allowed.
scoreboard players add #airdrop_timer pvp_timer 1
execute if score #airdrop_timer pvp_timer >= #airdrop_interval pvp_timer run function pvp:airdrop/spawn
execute unless entity @e[type=minecraft:wither_skeleton,tag=pvp_airdrop_guard,limit=1] as @e[type=minecraft:marker,tag=pvp_airdrop_marker,tag=!pvp_airdrop_unlocked] run function pvp:airdrop/unlock
execute as @e[type=minecraft:marker,tag=pvp_airdrop_marker] at @s unless data block ~ ~ ~ Items[0] run function pvp:airdrop/cleanup
