# Kit Sword + Bow - FULL MAX OP
clear @s

# Armor
item replace entity @s armor.head with netherite_helmet[enchantments={protection:4,respiration:3,unbreaking:3,mending:1}]
item replace entity @s armor.chest with netherite_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]
item replace entity @s armor.legs with netherite_leggings[enchantments={protection:4,soul_speed:3,unbreaking:3,mending:1}]
item replace entity @s armor.feet with netherite_boots[enchantments={protection:4,feather_falling:4,depth_strider:3,unbreaking:3,mending:1}]
item replace entity @s weapon.offhand with totem_of_undying

# Weapons
give @s netherite_sword[enchantments={sharpness:5,knockback:1,fire_aspect:2,looting:3,unbreaking:3,mending:1}]
give @s bow[enchantments={power:5,flame:1,punch:2,unbreaking:3,mending:1}]
give @s netherite_axe[enchantments={sharpness:5,efficiency:5,unbreaking:3,mending:1}]
give @s shield[enchantments={unbreaking:3,mending:1}]
give @s elytra[enchantments={unbreaking:3,mending:1}]

# Potions MAX
give @s splash_potion[potion_contents={potion:"minecraft:strong_healing"}] 3
give @s splash_potion[potion_contents={potion:"minecraft:strong_strength"}] 2
give @s splash_potion[potion_contents={potion:"minecraft:strong_swiftness"}] 2
give @s splash_potion[potion_contents={potion:"minecraft:strong_regeneration"}]
give @s splash_potion[potion_contents={potion:"minecraft:fire_resistance"}]

# Consumables
give @s arrow 192
give @s firework_rocket 192
give @s ender_pearl 32
give @s golden_apple 64
give @s enchanted_golden_apple 8
give @s totem_of_undying 8
give @s cooked_beef 64

tellraw @a {"text":"[ARENA] SWORD KIT MAX OP received!","color":"yellow"}