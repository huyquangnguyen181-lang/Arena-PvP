function pvp:track_kills
function pvp:boss/tick
function pvp:airdrop/tick
