scoreboard players operation @s pvp_tmp = @s pvp_player_kills
scoreboard players operation @s pvp_tmp -= @s pvp_player_seen
scoreboard players operation @s kills += @s pvp_tmp
scoreboard players operation @s pvp_player_seen = @s pvp_player_kills
tellraw @a ["",{"text":"[ARENA] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" eliminated a player! Kills: ","color":"white"},{"score":{"name":"@s","objective":"kills"},"color":"yellow","bold":true}]
title @s times 5 20 5
title @s title {"text":"+1 KILL","color":"green","bold":true}
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
function pvp:update_rank
