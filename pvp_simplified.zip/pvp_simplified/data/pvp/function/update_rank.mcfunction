execute if score @s kills matches 0..4 run team join warrior @s
execute if score @s kills matches 5..19 run team join knight @s
execute if score @s kills matches 20..49 run team join champion @s
execute if score @s kills matches 50.. run team join legend @s
