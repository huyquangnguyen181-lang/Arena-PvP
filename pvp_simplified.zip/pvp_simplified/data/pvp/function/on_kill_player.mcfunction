# On Kill Player - Random 1-3 items MAX
scoreboard players add @s kills 1
tellraw @a ["",{"text":"[ARENA] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" eliminated an enemy! Kills: ","color":"white"},{"score":{"name":"@s","objective":"kills"},"color":"yellow","bold":true}]
title @s times 5 20 5
title @s title {"text":"+1","color":"green","bold":true}
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1

# Random rewards MAX
execute if predicate pvp:random_50 run give @s totem_of_undying
execute if predicate pvp:random_50 run give @s golden_apple 2
execute if predicate pvp:random_50 run give @s firework_rocket 32
execute if predicate pvp:random_50 run give @s wind_charge 32
execute if predicate pvp:random_50 run give @s ender_pearl 8
execute if predicate pvp:random_50 run give @s splash_potion[potion_contents={potion:"minecraft:strong_healing"}]
execute if predicate pvp:random_50 run give @s splash_potion[potion_contents={potion:"minecraft:strong_strength"}]
execute if predicate pvp:random_50 run give @s splash_potion[potion_contents={potion:"minecraft:strong_regeneration"}]

# Rank
execute if score @s kills matches 0..4 run team join warrior @s
execute if score @s kills matches 5..19 run team join knight @s
execute if score @s kills matches 20..49 run team join champion @s
execute if score @s kills matches 50.. run team join legend @s

advancement revoke @s only pvp:kill_player