execute as @a if score @s pvp_player_kills > @s pvp_player_seen run function pvp:on_kill_player_scoreboard
execute as @a if score @s pvp_zombie_kills > @s pvp_zombie_seen run function pvp:on_kill_zombie_scoreboard
