kill @e[type=!player,distance=..100]
kill @e[type=item,distance=..100]
effect clear @a
effect give @a minecraft:regeneration 10 2
effect give @a minecraft:saturation 1 10
scoreboard players set @a kills 0
team join warrior @a
player Technoblade disconnect
player Wembbu disconnect
player Brandon disconnect
tellraw @a {"text":"[ARENA] Reset done! No blocks changed!","color":"green"}
