# ===== PVP ARENA SETUP =====

# WORLD
gamerule keep_inventory true

time set noon
weather clear

# ===== SCOREBOARD =====
scoreboard objectives remove kills
scoreboard objectives remove pvp_random
scoreboard objectives remove pvp_player_kills
scoreboard objectives remove pvp_zombie_kills
scoreboard objectives remove pvp_player_seen
scoreboard objectives remove pvp_zombie_seen
scoreboard objectives remove pvp_timer
scoreboard objectives remove pvp_tmp

scoreboard objectives add kills dummy
scoreboard objectives add pvp_random dummy
scoreboard objectives add pvp_player_kills minecraft.killed:minecraft.player
scoreboard objectives add pvp_zombie_kills minecraft.killed:minecraft.zombie
scoreboard objectives add pvp_player_seen dummy
scoreboard objectives add pvp_zombie_seen dummy
scoreboard objectives add pvp_timer dummy
scoreboard objectives add pvp_tmp dummy
scoreboard players set #boss_interval pvp_timer 12000
scoreboard players set #boss_timer pvp_timer 0
scoreboard players set #airdrop_interval pvp_timer 18000
scoreboard players set #airdrop_timer pvp_timer 0
scoreboard players set #zero pvp_tmp 0
scoreboard players set #hundred pvp_tmp 100
scoreboard players set #boss_max_hp pvp_tmp 300

scoreboard objectives setdisplay sidebar kills

# ===== TEAMS =====
team add warrior
team add knight
team add champion
team add legend

# ===== RESET KILLS =====
scoreboard players set @a kills 0

# ===== MESSAGE =====
tellraw @a {"text":"[ARENA] PvP Setup Completed!","color":"aqua","bold":true}
