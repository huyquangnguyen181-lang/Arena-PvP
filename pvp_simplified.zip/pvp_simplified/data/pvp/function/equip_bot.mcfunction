# Equip all bot players with full Netherite OP

playerspawn Wembbu at 50 -31 36
playerspawn Technoblade at 53 -31 38
playerspawn Brandon at 48 -31 35

item replace entity Wembbu armor.head with netherite_helmet[enchantments={protection:4,respiration:3,unbreaking:3,mending:1}]
item replace entity Wembbu armor.chest with netherite_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]
item replace entity Wembbu armor.legs with netherite_leggings[enchantments={protection:4,soul_speed:3,unbreaking:3,mending:1}]
item replace entity Wembbu armor.feet with netherite_boots[enchantments={protection:4,feather_falling:4,depth_strider:3,unbreaking:3,mending:1}]
item replace entity Wembbu weapon.mainhand with netherite_sword[enchantments={sharpness:5,fire_aspect:2,unbreaking:3,mending:1}]
item replace entity Wembbu hotbar.8 with shield[enchantments={unbreaking:3,mending:1}]
item replace entity Wembbu weapon.offhand with minecraft:totem_of_undying[custom_name={text:"Totem – Strong Health II",color:"yellow",bold:true,italic:false},enchantments={unbreaking:1},attribute_modifiers=[{id:"minecraft:strong_health",type:"minecraft:max_health",amount:20,operation:"add_value",slot:"offhand"}]] 64

item replace entity Technoblade armor.head with netherite_helmet[enchantments={protection:4,respiration:3,unbreaking:3,mending:1}]
item replace entity Technoblade armor.chest with netherite_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]
item replace entity Technoblade armor.legs with netherite_leggings[enchantments={protection:4,soul_speed:3,unbreaking:3,mending:1}]
item replace entity Technoblade armor.feet with netherite_boots[enchantments={protection:4,feather_falling:4,depth_strider:3,unbreaking:3,mending:1}]
item replace entity Technoblade weapon.mainhand with netherite_sword[enchantments={sharpness:5,fire_aspect:2,unbreaking:3,mending:1}]
item replace entity Technoblade weapon.offhand with shield[enchantments={unbreaking:3,mending:1}]

item replace entity Fruitberries armor.head with netherite_helmet[enchantments={protection:4,respiration:3,unbreaking:3,mending:1}]
item replace entity Fruitberries armor.chest with netherite_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]
item replace entity Fruitberries armor.legs with netherite_leggings[enchantments={protection:4,soul_speed:3,unbreaking:3,mending:1}]
item replace entity Fruitberries armor.feet with netherite_boots[enchantments={protection:4,feather_falling:4,depth_strider:3,unbreaking:3,mending:1}]
item replace entity Fruitberries weapon.mainhand with netherite_sword[enchantments={sharpness:5,fire_aspect:2,unbreaking:3,mending:1}]
item replace entity Fruitberries weapon.offhand with shield[enchantments={unbreaking:3,mending:1}]

item replace entity Brandon armor.head with netherite_helmet[enchantments={protection:4,respiration:3,unbreaking:3,mending:1}]
item replace entity Brandon armor.chest with netherite_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]
item replace entity Brandon armor.legs with netherite_leggings[enchantments={protection:4,soul_speed:3,unbreaking:3,mending:1}]
item replace entity Brandon armor.feet with netherite_boots[enchantments={protection:4,feather_falling:4,depth_strider:3,unbreaking:3,mending:1}]
item replace entity Brandon weapon.mainhand with netherite_sword[enchantments={sharpness:5,fire_aspect:2,unbreaking:3,mending:1}]
item replace entity Brandon weapon.offhand with shield[enchantments={unbreaking:3,mending:1}]

tellraw @a {"text":"[ARENA] All 4 bots equipped with full Netherite OP!","color":"green"}
