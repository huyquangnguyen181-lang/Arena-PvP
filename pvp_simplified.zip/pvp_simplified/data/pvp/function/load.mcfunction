# Load
scoreboard objectives add kills dummy
scoreboard objectives add pvp_random dummy
scoreboard objectives add pvp_player_kills minecraft.killed:minecraft.player
scoreboard objectives add pvp_zombie_kills minecraft.killed:minecraft.zombie
scoreboard objectives add pvp_player_seen dummy
scoreboard objectives add pvp_zombie_seen dummy
scoreboard objectives add pvp_timer dummy
scoreboard objectives add pvp_tmp dummy
scoreboard objectives setdisplay sidebar kills
scoreboard players set #boss_interval pvp_timer 12000
scoreboard players set #boss_timer pvp_timer 0
scoreboard players set #airdrop_interval pvp_timer 18000
scoreboard players set #airdrop_timer pvp_timer 0
scoreboard players set #zero pvp_tmp 0
scoreboard players set #hundred pvp_tmp 100
scoreboard players set #boss_max_hp pvp_tmp 300
bossbar add pvp:boss_hp_1 {"text":"BOSS #1","color":"red","bold":true}
bossbar add pvp:boss_hp_2 {"text":"BOSS #2","color":"gold","bold":true}
bossbar add pvp:boss_hp_3 {"text":"BOSS #3","color":"dark_red","bold":true}
bossbar set pvp:boss_hp_1 color red
bossbar set pvp:boss_hp_2 color yellow
bossbar set pvp:boss_hp_3 color purple
bossbar set pvp:boss_hp_1 max 300
bossbar set pvp:boss_hp_2 max 300
bossbar set pvp:boss_hp_3 max 300
bossbar set pvp:boss_hp_1 visible false
bossbar set pvp:boss_hp_2 visible false
bossbar set pvp:boss_hp_3 visible false
function pvp:airdrop/cleanup
tellraw @a {"text":"[ARENA] Loaded! /function pvp:test_help","color":"gold"}
