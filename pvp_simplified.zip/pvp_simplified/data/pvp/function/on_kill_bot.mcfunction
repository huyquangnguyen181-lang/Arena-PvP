# ==========================================
# PVP ARENA - ON KILL
# Player / Mob / Bot
# ==========================================

# +1 KILL
scoreboard players add @s kills 1

# ==========================================
# KILL MESSAGE
# ==========================================

tellraw @a ["",{"text":"[ARENA] ","color":"gold","bold":true},{"selector":"@s","color":"white"},{"text":" killed an enemy! Kills: ","color":"white"},{"score":{"name":"@s","objective":"kills"},"color":"yellow","bold":true}]

# ==========================================
# TITLE
# ==========================================

title @s times 5 20 5
title @s title {"text":"+1 KILL","color":"green","bold":true}

# ==========================================
# SOUND
# ==========================================

playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1

# ==========================================
# RANDOM REWARD
# 1-3 ITEMS
# ==========================================

# Roll 1
execute store result score #reward1 pvp_random run random value 1..8

execute if score #reward1 pvp_random matches 1 run give @s minecraft:totem_of_undying 1
execute if score #reward1 pvp_random matches 2 run give @s minecraft:golden_apple 1
execute if score #reward1 pvp_random matches 3 run give @s minecraft:firework_rocket 16
execute if score #reward1 pvp_random matches 4 run give @s minecraft:wind_charge 16
execute if score #reward1 pvp_random matches 5 run give @s minecraft:ender_pearl 4
execute if score #reward1 pvp_random matches 6 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_healing"}] 1
execute if score #reward1 pvp_random matches 7 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_strength"}] 1
execute if score #reward1 pvp_random matches 8 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_swiftness"}] 1

# Roll 2
execute store result score #reward2 pvp_random run random value 1..8

execute if score #reward2 pvp_random matches 1 run give @s minecraft:totem_of_undying 1
execute if score #reward2 pvp_random matches 2 run give @s minecraft:golden_apple 1
execute if score #reward2 pvp_random matches 3 run give @s minecraft:firework_rocket 16
execute if score #reward2 pvp_random matches 4 run give @s minecraft:wind_charge 16
execute if score #reward2 pvp_random matches 5 run give @s minecraft:ender_pearl 4
execute if score #reward2 pvp_random matches 6 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_healing"}] 1
execute if score #reward2 pvp_random matches 7 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_strength"}] 1
execute if score #reward2 pvp_random matches 8 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_swiftness"}] 1

# Roll 3
execute store result score #reward3 pvp_random run random value 1..8

execute if score #reward3 pvp_random matches 1 run give @s minecraft:totem_of_undying 1
execute if score #reward3 pvp_random matches 2 run give @s minecraft:golden_apple 1
execute if score #reward3 pvp_random matches 3 run give @s minecraft:firework_rocket 16
execute if score #reward3 pvp_random matches 4 run give @s minecraft:wind_charge 16
execute if score #reward3 pvp_random matches 5 run give @s minecraft:ender_pearl 4
execute if score #reward3 pvp_random matches 6 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_healing"}] 1
execute if score #reward3 pvp_random matches 7 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_strength"}] 1
execute if score #reward3 pvp_random matches 8 run give @s minecraft:splash_potion[potion_contents={potion:"minecraft:strong_swiftness"}] 1

# ==========================================
# RANK
# ==========================================

execute if score @s kills matches 0..4 run team join warrior @s
execute if score @s kills matches 5..19 run team join knight @s
execute if score @s kills matches 20..49 run team join champion @s
execute if score @s kills matches 50.. run team join legend @s

# ==========================================
# REMOVE USED ADVANCEMENT
# ==========================================

advancement revoke @s only pvp:kill_bot
