# Heal MAX
effect give @s minecraft:regeneration 10 2
effect give @s minecraft:saturation 1 10
effect clear @s minecraft:poison
effect clear @s minecraft:weakness
effect clear @s minecraft:slowness
tellraw @a {"text":"[ARENA] Fully healed!","color":"green"}