function pvp:reward/roll_item
function pvp:reward/roll_item
execute if predicate pvp:random_50 run function pvp:reward/roll_item
